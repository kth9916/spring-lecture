package polymorphism_5_1_1;

public interface Speaker {

	void volumUp();

	void volumDown();

}