package polymorphism_4_3_2;

public interface Speaker {

	void volumUp();

	void volumDown();

}